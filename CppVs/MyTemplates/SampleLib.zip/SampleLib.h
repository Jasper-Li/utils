#pragma once
class $projectname$
{
};

